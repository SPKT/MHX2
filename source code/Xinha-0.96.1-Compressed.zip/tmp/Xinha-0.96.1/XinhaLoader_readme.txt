The XinhaLoader is a subset of Xinha only containing functions to fetch further files from the server and displaying a loading message. 
It gives visual feedback to the user quite quickly so they don't have to watch the plain textarea and wonder if anything is happening.

Usage in short: Follow the NewbieGuide, but load XinhaLoader.js instead of XinhaCore.js. 
Make shure you define xinha_editors before calling Xinha.loadPlugins! This is different to earlier versions of the NewbieGuide (steps 1 and 2 reversed)