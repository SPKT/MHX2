// I18N constants
// LANG: "de", ENCODING: UTF-8
{ 
	"Save": "Speichern",
	"Saving...": "Speichern...",
	"in progress": "in Arbeit",
	"Ready": "Fertig"
};