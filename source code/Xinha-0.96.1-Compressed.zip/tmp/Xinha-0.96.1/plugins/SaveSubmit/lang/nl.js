// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{ 
	"Save": "Opslaan",
	"Saving...": "Bezig met opslaan...",
	"in progress": "bezig met opslaan...",
	"Ready": "Klaar"
};