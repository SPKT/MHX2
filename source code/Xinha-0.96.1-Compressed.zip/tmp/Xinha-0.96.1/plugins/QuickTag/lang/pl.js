// I18N constants
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz, http://www.eskot.krakow.pl/portfolio/, koto@webworkers.pl
{ 
  "Quick Tag Editor": "Edytor Quick Tag",
  "Enter the TAG you want to insert": "Podaj TAG, który chcesz wstawić",
  "You have to select some text": "Musisz zaznaczyć tekst.",
  "There are some unclosed quote": "Są jakieś niezamknięte cudzysłowia",
  "This attribute already exists in the TAG": "TAG posiada już ten atrybut",
  "No CSS class avaiable": "Brak dostępnych klas CSS",
  "OPTIONS": "OPCJE",
  "ATTRIBUTES": "ATRYBUTY",
  "TAGs": "TAGi",
  "Colors": "Kolory",
  "Ok": "Ok",
  "Cancel": "Anuluj"
};
