// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Page break": "改ページ"
};