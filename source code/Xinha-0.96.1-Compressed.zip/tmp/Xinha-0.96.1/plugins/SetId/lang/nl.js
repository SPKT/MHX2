// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Set Id and Name": "ID en Naam instellen",
  "Name/Id": "Naam/ID",
  "Delete": "Verwijderen",
  "Set ID/Name": "ID/Naam instellen",
  "ID/Name:": "ID/Naam:"
};