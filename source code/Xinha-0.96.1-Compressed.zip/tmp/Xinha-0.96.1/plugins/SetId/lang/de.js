// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Raimund Meyer xinha@ray-of-light.org
{
  "Set Id and Name": "Objekt ID und Name einfügen",
  "Name/Id": "Name (ID)",
  "Delete": "Löschen"
};
