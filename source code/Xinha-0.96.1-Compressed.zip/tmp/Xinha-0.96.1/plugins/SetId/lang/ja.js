// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Set Id and Name": "IDと名前の設定",
  "Name/Id": "名前/ID",
  "Delete": "削除",
  "Set ID/Name": "IDと名前の設定",
  "ID/Name:": "ID/名前:"
};