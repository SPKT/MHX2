// I18N constants
// LANG: "fr_ca", ENCODING: UTF-8
{
  "You have unsaved changes in the editor": "Tu n'as pas enregistré tes modifications"
};
