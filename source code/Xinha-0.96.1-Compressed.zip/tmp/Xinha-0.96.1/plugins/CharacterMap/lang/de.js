// I18N constants
// LANG: "de", ENCODING: UTF-8
// Sponsored by http://www.systemconcept.de
// Author: Holger Hees, <hhees@systemconcept.de>
// (c) systemconcept.de 2004
// Distributed under the same terms as HTMLArea itself.
// This notice MUST stay intact for use (see license.txt).
{
  "Insert special character": "Sonderzeichen einfügen",
  "Cancel": "Abbrechen"
}
