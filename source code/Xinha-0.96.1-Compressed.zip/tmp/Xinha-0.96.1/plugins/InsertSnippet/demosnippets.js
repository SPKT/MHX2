var snippets = [];
var i = 0;
snippets[i] = {};
snippets[i]['id'] = 'Box 1';
snippets[i]['HTML'] = '<div class="message_box red">\n  Visit the <a href="http://xinha.org">Xinha website</a></div>';

i++;
snippets[i] = {};
snippets[i]['id'] = 'INFORMATION ABOUT SOMETHING';
snippets[i]['HTML'] = '<div class="message_box green">\n  This is an information about something\n</div>';

i++;
snippets[i] = {};
snippets[i]['id'] = 'Menu';
snippets[i]['HTML'] = '<ul class="navi_links">\n	<li class="navi">\n		<a href="Link1" class="Link1" tabindex="1"><span class="span_class">Link1</span></a>\n    </li>\n	\n	<li class="navi">\n		<a href="Link2" class="Link2" tabindex="2"><span class="span_class">Link2</span></a>\n    </li>\n\n	\n	<li class="navi">\n		<a href="Link3" class="Link3" tabindex="3"><span class="span_class">Link3</span></a>\n    </li>\n	\n	<li class="navi">\n		<a href="Link4" class="Link4" tabindex="4"><span class="span_class">Link4</span></a>\n    </li>\n	\n	<li class="navi">\n		<a href="Link5" class="Link5" tabindex="5"><span class="span_class">Link5</span></a>\n\n    </li>\n\n</ul>';