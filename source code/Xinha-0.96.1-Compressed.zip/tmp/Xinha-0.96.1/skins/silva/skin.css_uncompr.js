/*--------------------------------*/ 
/*      silva skin for Xinha      */ 
/*                                */ 
/*      by Raimund Meyer (ray)    */ 
/*      xinha@raimundmeyer.de     */
/*           2007-1-9             */ 
/*--------------------------------*/ 

.htmlarea .toolbar, .htmlarea .toolbar .button
{
  background-color:transparent;
}
.htmlarea .toolbar
{
  padding:0;
  background-image: url(toolbar.png);
}
.htmlarea .toolbarRow
{
  margin-top:0px;
  margin-bottom:0px;
  border:1px solid #F1F1F1;
  padding:0px;
  -moz-border-radius:15px;
  margin:4px;
  height:20px;
}
/* hack: IE6 does not know border-color: transparent;*/
html > body .htmlarea .toolbarRow {
  border-color: transparent;
}

.htmlarea .toolbar .button
{
  width:18px;
  height:18px;
  padding:1px 2px 2px 1px ;
  border: solid #F1F1F1;
  border-width:1px;
}

html > body .htmlarea .toolbar .button {
  border-color: transparent;
}

.buttonImageContainer
{
  position:relative;
  left:1px;
  top :1px;
}

.htmlarea .toolbar a.button:hover
{
  border: solid 1px;
  border-color: black;
}
.htmlarea .toolbar a.buttonDisabled:hover
{
  border: solid transparent 1px;
}

.htmlarea .toolbar .button.buttonActive,
.htmlarea .toolbar .button.buttonPressed
{
  border: black dotted 1px;
  padding:2px 1px 1px 2px;  
}

.htmlarea .toolbar .button.buttonPressed {
  padding:1px 2px 2px 1px ;
}
.htmlarea .toolbar .separator {
  margin: 3px;
  border-left: 1px dotted black;
  border-right: none;
  width: 1px;
  height: 11px;
  padding: 0px;
}

.htmlarea .statusBar {
  border-color: #CCC white white #CCC;
  padding: 0px;
  height:20px;
  background-image: url(statusbar.png);
  background-repeat: repeat-x;
  background-color: white;
  color: grey;
  font: 11px Arial,Helvetica,sans-serif;
  vertical-align: middle;
}

.htmlarea .statusBar .statusBarWidgetContainer
{
  background-image: url(statusbar.png);
  background-repeat: repeat-x;
  background-color: white;
}

.htmlarea .statusBar .statusBarTree
{
  display:block;
  margin: 3px;
}

.htmlarea .statusBar .statusBarTree a
{
  padding: 0 5px;
  color: green;
  text-decoration:none;
  letter-spacing:0.15em;
  font-size:120%;
  border: none;
  padding: 2px 5px;
}
.htmlarea .statusBar .statusBarTree a:visited { color:green; }
.htmlarea .statusBar .statusBarTree a:hover {
  background-color: transparent;
  color: green;
  border: none;
  padding: 1px 5px;
}

.dialog {
  /* background: url(dialog.jpg) #f0f0f0 no-repeat; */
  background-color: #f0f0f0;
 }
body.dialog {
	padding-top:0;
}
.dialog, .dialog button, .dialog input, .dialog select, .dialog textarea, .dialog table,.dialog td,.dialog th, .panel {
  font: 11px Arial,Helvetica,sans-serif !IMPORTANT;
}
.panel a {
  color:#444;
  border-bottom: 1px dotted #bbb;
}
.panel a:hover {
  background-color: #eee;
}
.dialog .title,.dialog  h1,.htmlarea .panel h1 {
  background-image: url(toolbar.png);
  background-repeat: repeat-x;
  color:black;
  font:Arial,Helvetica,sans-serif !IMPORTANT;
  letter-spacing:0.2em;
  font-size:13px;
  font-weight:400;
}  
.dialog .title {

}

.dialog button{
  background: url(statusbar.png) bottom repeat-x;
  border:1px solid grey;
  height:18px;
  vertical-align: middle
}
/* separate definition for the sake of IE6*/
.dialog input[type=button],.dialog input[type=submit]{
  background: url(statusbar.png) bottom repeat-x;
  border:1px solid grey;
  height:18px;
  vertical-align: middle
}
.htmlarea textarea.xinha_textarea {
  background:url(html.gif) bottom right no-repeat;
  /*padding:5px;
  border:2px dotted #bbb;*/
  font-family: "Lucida Console",Courier,monospace;
  font-size: 10pt;
}
.htmlarea .dTreeNode {
  color:black;
}
