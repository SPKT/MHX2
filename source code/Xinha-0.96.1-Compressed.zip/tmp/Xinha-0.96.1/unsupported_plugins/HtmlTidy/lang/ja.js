// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "HTML Tidy": "HTML Tidy",
  "Auto-Tidy": "自動適正化",
  "Don't Tidy": "適正化しない",
  "Tidy failed.  Check your HTML for syntax errors.":"適正化に失敗しました。HTMLの文法エラーを確認してください。"
};