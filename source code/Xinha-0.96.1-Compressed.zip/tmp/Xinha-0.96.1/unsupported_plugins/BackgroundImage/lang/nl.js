// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Set page background image": "Pagina achtergrond afbeelding instellen",
  "Set Page Background Image": "Pagina Achtergrond Afbeelding Instellen",
  "Remove Current Background": "Huidige Achtergrond Afbeelding Verwijderen",
  "Cancel": "Annuleren"
};
