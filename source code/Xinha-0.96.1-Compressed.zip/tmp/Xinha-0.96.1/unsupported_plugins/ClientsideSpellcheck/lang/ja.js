// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Spell Check using ieSpell": "スペルチェックに ieSpell を使う",
  "ieSpell can only be used in Internet Explorer": "ieSpell は Internet Explorer でのみ使用できます",
  "ieSpell not detected.  Click Ok to go to download page.": "ieSpell が検知されませんでした。OK をクリックしてダウンロードページを開いてください。"
};