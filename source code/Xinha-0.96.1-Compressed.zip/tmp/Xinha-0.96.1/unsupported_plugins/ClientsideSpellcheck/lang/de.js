// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "Spell Check using ieSpell": "Englische Rechtschreibkontrolle mit ieSpell",
  "ieSpell can only be used in Internet Explorer": "ieSpell kann nur mit dem Internet Explorer benutzt werden",
  "ieSpell not detected.  Click Ok to go to download page.": "ieSpell wurde nicht gefunden. Drücken sie Ok um ieSpeck herunter zu laden."
};
