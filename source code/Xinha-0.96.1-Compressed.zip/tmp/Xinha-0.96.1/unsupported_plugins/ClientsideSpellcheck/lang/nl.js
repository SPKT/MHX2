// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Spell Check using ieSpell": "Engelse spellingscontrole met ieSpell",
  "ieSpell can only be used in Internet Explorer": "ieSpell kan alleen worden gebruikt in Internet Explorer",
  "ieSpell not detected.  Click Ok to go to download page.": "ieSpell werd niet gevonden. Klik op Ok om ieSpell te downloaden"
};
