// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
	"Insert template"          : "テンプレートの挿入",
	"Cancel"                   : "中止"
};