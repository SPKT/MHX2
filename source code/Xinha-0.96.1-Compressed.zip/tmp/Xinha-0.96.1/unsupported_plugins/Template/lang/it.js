// I18N constants
// LANG: "it", ENCODING: UTF-8 | ISO-8859-1
{
  "Insert template": "Inserisca il template",
  "Cancel": "Annullamento"
};